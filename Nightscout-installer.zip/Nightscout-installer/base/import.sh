#!/bin/bash
#
# Developed by Rafael Corrêa Gomes
# Contact rafaelcgstz@gmail.com
#

# Import Colors
. base/color.sh

# Import message
. base/message.sh
