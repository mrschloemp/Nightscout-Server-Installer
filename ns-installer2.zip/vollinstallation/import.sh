#!/bin/bash
#
# Nightscout Server Installer
# by Michael Schlömp
# www.michael-schloemp.de
#

# Import Launch
. vollinstallation/launch.sh

